# ♻ BasuraFix

**Clasificador de residuos con una CNN entrenada sobre TrashNet + RealWaste + Garbage Classification (12 clases), con interfaz gráfica en español.**

![Interfaz de BasuraFix](reports/screenshot.png)

BasuraFix analiza una foto y responde tres cosas:

1. **Qué residuo es** (cartón, vidrio, metal, papel, plástico, orgánico, textil o basura general).
2. **Con qué confianza** (porcentaje + top-3 de probabilidades).
3. **Dónde depositarlo** y un consejo práctico de reciclaje.

Incluye **TTA** (test-time augmentation con espejo horizontal) y **Grad-CAM** para ver en qué zonas de la foto se fija la red.

---

## Inicio rápido (Windows)

El proyecto ya viene con el entorno y el modelo entrenado. Solo haz doble clic en:

```
ABRIR_INTERFAZ.bat
```

Si empiezas desde cero:

| Paso | Archivo | Qué hace |
|---|---|---|
| 1 | `1_INSTALAR.bat` | Crea `.venv` e instala PyTorch CPU + dependencias. |
| 2 | `2_DESCARGAR_DATOS.bat` | Descarga TrashNet, RealWaste y Garbage12, y crea el manifest. |
| 3 | `3_ENTRENAR.bat` | Entrena la CNN (~35–60 min en CPU, ~5 min con GPU). |
| 4 | `ABRIR_INTERFAZ.bat` | Abre la interfaz. |

Las versiones exactas de las dependencias están fijadas en `requirements.txt` (probado con **Python 3.14.3**; PyTorch CPU `2.14.1+cpu` y torchvision `0.29.1+cpu` se instalan aparte desde el índice CPU).

También funciona por consola (PowerShell):

```powershell
cd "$env:USERPROFILE\Downloads\basurafix"
$env:PYTHONPATH="$PWD\src"
.\.venv\Scripts\python.exe -m basurafix gui
```

### Clasificar una foto desde la consola

```powershell
$env:PYTHONPATH="$PWD\src"
.\.venv\Scripts\python.exe -m basurafix predict "C:\ruta\foto.jpg"
.\.venv\Scripts\python.exe -m basurafix predict "C:\ruta\foto.jpg" --explain reports\explicacion.png
```

---

## Resultados

> Entrenamiento: MobileNetV3-Large preentrenada en ImageNet, 224×224, 8 clases.
> Split estratificado 70/15/15 sobre el dataset combinado.

| Métrica | Valor |
|---|---|
| Precisión en test | **96,24 %** |
| F1 macro en test | **0,9615** |
| Precisión en test con TTA | **96,34 %** |
| F1 macro con TTA | **0,9626** |
| Top-3 en test | **99,79 %** |
| Mejor época | 15 |
| Imágenes de entrenamiento | 8.934 |
| Imágenes de validación | 1.914 |
| Imágenes de test | 1.914 |

Reportes generados automáticamente:

- `reports/classification_report.txt` — precisión/recall/F1 por clase.
- `reports/confusion_matrix.png` — matriz de confusión normalizada.
- `reports/training_history.png` — curvas de pérdida y F1.
- `reports/metrics.json` — todas las métricas y el historial.
- `reports/explain_botella.png` — Grad-CAM de la botella de prueba.
- `reports/explain_cartones.png` — Grad-CAM de la prueba con cartón.
- `reports/screenshot.png` — captura real de la interfaz.
- `reports/screenshot_cartones.png` — captura de la interfaz con la prueba de cartón.

### Prueba real con una botella

![Prueba con botella](samples/botella_plastico.jpg)

Resultado del modelo sobre `samples/botella_plastico.jpg`:

| Clase | Confianza |
|---|---|
| **Plástico** | **86,4 %** |
| Cartón | 3,0 % |
| Papel | 2,6 % |

### Prueba real con cartón

![Prueba con cartón](reports/screenshot_cartones.png)

Sobre `cartones.jpg` (un montón de cajas con watermarks y otros objetos): **Cartón 77,8 %**, Textil 7,2 %, Orgánico 3,8 %. El Grad-CAM se concentra en las cajas.

---

## Datasets

| Fuente | Imágenes | Clases originales | Licencia | Uso |
|---|---:|---|---|---|
| [TrashNet](https://github.com/garythung/trashnet) | 2.527 | 6 | MIT | Objetos limpios sobre fondo blanco |
| [RealWaste](https://huggingface.co/datasets/shahzaibvohra/realwaste) | 4.752 | 9 | CC BY 4.0 | Residuos reales en un vertedero |
| [Garbage Classification (12 clases)](https://huggingface.co/datasets/UdaraChamidu/Garbage-Classification-with-12-classes) | 15.520 | 12 | No especificada (uso educativo) | Vidrio de colores, ropa, calzado, biológicos y más |
| **Total usado** | **12.762** | **8 unificadas** | — | Tras deduplicar y limitar a 1.200 por clase |

Del dataset de 12 clases se excluyen las pilas (`battery`) por ser residuo peligroso y se limita cada clase a 1.200 imágenes para evitar que textil (7.302 imágenes entre ropa y calzado) o vidrio (2.016) dominen el entrenamiento. Tras unificar las tres fuentes se eliminaron **2.174 duplicados exactos** (SHA-1), quedando 12.762 imágenes.

![Muestras del dataset de 12 clases](reports/garbage12_samples.jpg)

### Taxonomía unificada

| Clase | TrashNet | RealWaste | Garbage12 | Contenedor (Perú, NTP 900.058) |
|---|---|---|---|---|
| Cartón | `cardboard` | `Cardboard` | `cardboard` | Azul |
| Vidrio | `glass` | `Glass` | `brown/green/white-glass` | Verde |
| Metal | `metal` | `Metal` | `metal` | Amarillo |
| Papel | `paper` | `Paper` | `paper` | Azul |
| Plástico | `plastic` | `Plastic` | `plastic` | Amarillo |
| Orgánico | — | `Food Organics` + `Vegetation` | `biological` | Marrón |
| Textil | — | `Textile Trash` | `clothes` + `shoes` | Punto de acopio |
| Basura general | `trash` | `Miscellaneous Trash` | `trash` | Negro/gris |

Se eliminan duplicados exactos por SHA-1 y se hace un split estratificado reproducible (`seed=42`).

---

## Cómo funciona el modelo

```
Imagen → redimensionar 224×224 → normalizar (ImageNet)
       → MobileNetV3-Large (backbone preentrenado)
       → cabeza densa de 8 clases
       → softmax + TTA (original + espejo) → top-3
```

**Entrenamiento en dos fases:**

1. **Cabeza (3 épocas):** backbone congelado, solo se entrena el clasificador. LR 1e-3.
2. **Fine-tuning (12 épocas):** se descongela toda la red con LR 3e-4 para el backbone y 6e-4 para la cabeza, cosine annealing y early stopping (paciencia 4).

**Regularización y balanceo:**

- RandomResizedCrop, flip horizontal, rotación ±12°, color jitter y blur suave.
- Label smoothing 0.1.
- Pesos de clase por frecuencia (raíz cuadrada, acotados).
- Recorte de gradiente (norma 5).
- Dropout 0.25 en la cabeza.

**Inferencia:**

- Redimensionado a 256 px y center crop de 224 px.
- Promedio de probabilidades de la imagen y su espejo horizontal (TTA).
- Aviso si la confianza es baja (&lt;45 %) o si las dos clases top están a menos de 10 puntos.

---

## Interfaz

- Selección de foto por diálogo o **arrastrando y soltando**.
- Formatos: JPG, PNG, WEBP, BMP, **AVIF** y **HEIC**.
- Vista previa, clase detectada, confianza grande y barra de progreso.
- Top-3 con barras de probabilidad.
- Contenedor recomendado con el color real del contenedor.
- Consejo de reciclaje.
- **Mapa de calor Grad-CAM** en una ventana aparte.
- Atajos: `Ctrl+O` abrir, `Esc` limpiar, `F5` volver a analizar.
- Funciona sin GPU: ~0,04 s por imagen en CPU.

---

## Estructura del proyecto

```
basurafix/
├── 1_INSTALAR.bat
├── 2_DESCARGAR_DATOS.bat
├── 3_ENTRENAR.bat
├── ABRIR_INTERFAZ.bat
├── requirements.txt
├── src/basurafix/
│   ├── config.py          # clases, colores, rutas, alias de etiquetas
│   ├── download_data.py   # descarga TrashNet + RealWaste + Garbage12
│   ├── prepare_data.py    # unifica, deduplica y divide
│   ├── dataset.py         # Dataset + aumentos + DataLoader
│   ├── model.py           # MobileNetV3/EfficientNet/ConvNeXt/ResNet
│   ├── train.py           # entrenamiento en 2 fases + métricas
│   ├── predict.py         # inferencia + TTA
│   ├── gradcam.py         # mapas de calor
│   └── gui.py             # interfaz Tkinter
├── data/
│   ├── raw/               # TrashNet, RealWaste y Garbage12 originales
│   └── processed/manifest.csv
├── models/basurafix_mobilenetv3.pt
├── reports/               # métricas, curvas, matriz de confusión
└── samples/               # fotos de prueba
```

El manifest guarda **rutas relativas**, así que puedes mover la carpeta del proyecto sin romper nada (siempre que muevas también `data/`).

---

## Añadir más datasets (opcional)

Cualquier dataset con **una carpeta por clase** puede sumarse. Por ejemplo:

```
D:\datasets\mi_basura\
├── plastic\      (o "plástico", "PET", "botellas"...)
├── glass\
├── paper\
└── organic\
```

Ejecuta:

```powershell
$env:PYTHONPATH="$PWD\src"
.\.venv\Scripts\python.exe -m basurafix prepare --extra "mi_basura=D:\datasets\mi_basura"
.\.venv\Scripts\python.exe -m basurafix train --arch mobilenet_v3_large
```

`config.py` incluye alias en inglés y español (`cardboard/cartón`, `plastic/plástico/PET`, `organic/food organics/vegetation`, `textile/clothes`, etc.). Las clases desconocidas se ignoran con un aviso.

Para volver al dataset original, borra `data/processed/manifest.csv` y ejecuta `prepare` de nuevo.

---

## Consejos para la mejor precisión

1. **Un solo objeto** por foto, centrado y ocupando la mayor parte del encuadre.
2. **Buena luz**, sin sombras duras ni contraluz.
3. **Fondo limpio** y contrastante (la red aprendió mucho de fondos blancos y de vertedero).
4. Evita fotos muy oscuras, borrosas o con varios residuos mezclados.
5. Si la confianza es baja, prueba desde otro ángulo y compara el top-3.
6. El **Grad-CAM** ayuda a detectar si el modelo está mirando el objeto o el fondo.

---

## Limitaciones

- Es un **clasificador de una sola etiqueta**: si hay varios objetos, elegirá el dominante.
- No detecta objetos ni segmenta: no hay cajas delimitadoras.
- Las clases `textil` y `orgánico` tienen menos variedad que las demás, aunque Garbage12 aporta ropa, calzado y residuos biológicos.
- Un residuo muy ambiguo (p. ej. un envase de vidrio opaco) puede confundirse con plástico o metal.
- El porcentaje es la probabilidad estimada por la softmax, no una garantía. Con confianza &lt;45 % conviene revisar la foto.
- El modelo no está pensado para residuos peligrosos (pilas, medicamentos, químicos).

---

## Créditos y licencias

- **TrashNet** — Gary Thung & Mindy Yang (Stanford), licencia MIT.
  <https://github.com/garythung/trashnet>
- **RealWaste** — University of Wollongong, licencia CC BY 4.0.
  <https://huggingface.co/datasets/shahzaibvohra/realwaste>
- **Garbage Classification (12 clases)** — licencia no especificada por el autor; uso educativo.
  <https://huggingface.co/datasets/UdaraChamidu/Garbage-Classification-with-12-classes>
- **PyTorch / torchvision** — pesos ImageNet de MobileNetV3.
- Código de BasuraFix — uso libre para fines educativos y de investigación.

Las imágenes de los datasets conservan sus licencias originales. Si redistribuyes el modelo o el proyecto, mantén la atribución a TrashNet, RealWaste y Garbage Classification.
